package com.example.homework.service;

import com.example.homework.dto.ArticleListResponseDto;
import com.example.homework.dto.ArticleRequestDto;
import com.example.homework.dto.ArticleResponseDto;
import com.example.homework.dto.ResponseDto;
import com.example.homework.entity.Article;
import com.example.homework.entity.User;
import com.example.homework.jwt.JwtUtil;
import com.example.homework.repository.ArticleRepository;
import com.example.homework.repository.UserRepository;
import io.jsonwebtoken.Claims;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ArticleService {
    private final ArticleRepository articleRepository;
    private final UserRepository userRepository;
    private final JwtUtil jwtUtil;

    @Transactional
    public ResponseDto saveArticle(ArticleRequestDto requestDto, HttpServletRequest request) {
        String token = jwtUtil.resolveToken(request);
        System.out.println("token = " + token);
        Claims claims;
        if (token != null) {
            if (jwtUtil.validateToken(token)) {
                // 토큰에서 사용자 정보 가져오기
                claims = jwtUtil.getUserInfoFromToken(token);
            } else {
                throw new IllegalArgumentException("Token Error");
            }
            User user = userRepository.findByUsername(claims.getSubject()).orElseThrow(
                    () -> new IllegalArgumentException("사용자가 존재하지 않습니다.")
            );
            Article article = articleRepository.saveAndFlush(new Article(requestDto));
            articleRepository.save(article);
            return new ResponseDto("글 등록 완료", HttpStatus.OK.value());
        }
        else {
            return new ResponseDto("애러발생", HttpStatus.OK.value());
        }
    }
    @Transactional(readOnly = true)
    public ArticleListResponseDto getArticles() {
        ArticleListResponseDto articleListResponseDto = new ArticleListResponseDto();
        List<Article> articles = articleRepository.findAll();
        for(Article article :articles){
            articleListResponseDto.addArticle(new ArticleResponseDto(article));
        }
        return articleListResponseDto;
    }
    @Transactional(readOnly = true)
    public ArticleResponseDto getArticle(Long id) {
        Article article = articleRepository.findById(id).orElseThrow(
                ()-> new RuntimeException("글이없다")
        );
        return new ArticleResponseDto(article);
    }
    @Transactional
    public ArticleResponseDto updateArticle(Long id, ArticleResponseDto requestDto, HttpServletRequest request) {
        // Request에서 Token 가져오기
        String token = jwtUtil.resolveToken(request);
        Claims claims;

        // 토큰이 있는 경우에만 관심상품 최저가 업데이트 가능
        if (token != null) {
            // Token 검증
            if (jwtUtil.validateToken(token)) {
                // 토큰에서 사용자 정보 가져오기
                claims = jwtUtil.getUserInfoFromToken(token);
            } else {
                throw new IllegalArgumentException("Token Error");
            }

            Article article = articleRepository.findById(id).orElseThrow(
                    ()-> new RuntimeException("글이 없다")
            );

            article.update(requestDto);

            return new ArticleResponseDto(article);

        } else {
            return null;
        }

    }
    @Transactional
    public ArticleResponseDto updateArticle(Long id, ArticleResponseDto responseDto) {
        Article article = articleRepository.findById(id).orElseThrow(
                ()-> new RuntimeException("글이 없다")
        );
        article.update(responseDto);
        return new ArticleResponseDto(article);
    }
    @Transactional
    public boolean deleteArticle(Long id,String password){
        if (articleRepository.existsByIdAndPassword(id, password)) {
            articleRepository.deleteById(id);
            return true;
        }
        return false;
    }
    public ResponseDto deleteCourse(Long id) {
        Article article = articleRepository.findById(id).orElseThrow(
                ()-> new RuntimeException("글이 없다")
        );

        articleRepository.delete(article);
        return new ResponseDto("삭제 성공", HttpStatus.OK.value());
    }
}

//if(article.getUsername().equals(user.getUsername())==false){
//if(user.getUsername().equals(article.getUsername())==false){

