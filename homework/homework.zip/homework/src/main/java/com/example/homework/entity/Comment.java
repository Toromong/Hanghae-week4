package com.example.homework.entity;

public class Comment {
}
